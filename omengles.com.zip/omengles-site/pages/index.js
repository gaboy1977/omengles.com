
export default function Home() {
  return (
    <main className="bg-gray-100 min-h-screen flex flex-col justify-center items-center font-sans text-gray-900">
      <header className="w-full max-w-4xl mx-auto p-6 flex justify-between items-center">
        <h1 className="font-bold text-3xl text-blue-600">OMENGLES<span className="text-black">.COM</span></h1>
        <nav className="space-x-4">
          <a href="#" className="text-gray-700 hover:text-blue-500">Home</a>
          <a href="#" className="text-gray-700 hover:text-blue-500">About</a>
          <a href="#" className="text-gray-700 hover:text-blue-500">Contact</a>
        </nav>
      </header>

      <section className="flex flex-col items-center text-center p-10">
        <h2 className="text-5xl font-bold mb-6">Talk to Strangers, Instantly.</h2>
        <p className="text-gray-600 mb-8">Connect, chat, and meet new people across the world. No registration required.</p>
        <button className="bg-blue-600 hover:bg-blue-700 text-white font-semibold px-8 py-4 rounded-full shadow-md transition">Start Chatting</button>
      </section>

      <footer className="w-full text-center text-gray-500 text-sm py-6 border-t border-gray-300">
        © 2025 OMENGLES.COM — All rights reserved.
      </footer>
    </main>
  );
}
